﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserCRUD.Data;
using UserCRUD.Models;

namespace UserCRUD.Interface
{
    public interface IUserRepository
    {
        List<UserTbl> GetUsers(User_Get_DTO user_Get_DTO, ref ReturnObject obj);
        UserTbl GetUser(User_Get_DTO user_Get_DTO, ref ReturnObject obj);
        void InsertUser(User_Post_DTO user_Post_DTO, ref ReturnObject obj);
        void UpdateUser(User_Post_DTO user_Post_DTO, ref ReturnObject obj);
        void DeleteUser(User_Post_DTO user_Post_DTO, ref ReturnObject obj);

        UserTbl Login(string Password, ref ReturnObject obj);

        string TestApi(string text, ref ReturnObject obj);
    }
}
