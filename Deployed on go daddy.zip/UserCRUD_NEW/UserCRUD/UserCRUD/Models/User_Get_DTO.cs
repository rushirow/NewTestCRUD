﻿namespace UserCRUD.Models
{
    public class User_Get_DTO
    {
        public int UserId { get; set; }
    }
}