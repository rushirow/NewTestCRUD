﻿using System;

namespace UserCRUD.Models
{
    public class User_Post_DTO
    {
        public int UserId { get; set; }
        public string ForeName { get; set; }
        public string SurName { get; set; }
        public string Email { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}