﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using UserCRUD.Data;

namespace UserCRUD.WebApiModel
{
    public class UserApiModel
    {
        public List<UserTbl> Users;
        public UserTbl User;
        public bool ReturnStatus;
        public List<string> ReturnMessage;

        public string TokenValue { get; set; }
        public string TestApi { get; set; }

    }
}