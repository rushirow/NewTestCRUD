﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UserCRUD.Data;
using UserCRUD.Interface;
using UserCRUD.Models;
using UserCRUD.Repository;
using UserCRUD.WebApiModel;

namespace UserCRUD.Controllers
{
    public class UserController : ApiController
    {
        private readonly IUserRepository userRepository;
        public ReturnObject obj;
        private UserApiModel userApiModel;

        public UserController()
        {
            userRepository = new UserRepository();
            obj = new ReturnObject();
            userApiModel = new UserApiModel();
        }

        [Authorize]
        [HttpGet]
        [Route("api/User")]
        public HttpResponseMessage GetUser([FromUri] User_Get_DTO User_Get_DTO)
        {
            try
            {
                userApiModel.User = userRepository.GetUser(User_Get_DTO, ref obj);

                //int i = 0;
                //int j = 10 / i;

                userApiModel.ReturnStatus = obj.ReturnStatus;
                userApiModel.ReturnMessage = obj.ReturnMessage;

                return Request.CreateResponse<UserApiModel>(HttpStatusCode.OK, userApiModel);
            }
            catch (Exception e)
            {
                userApiModel.ReturnStatus = false;
                //userApiModel.ReturnMessage.Add("Something went wrong");
                userApiModel.ReturnMessage.Add(e.Message);

                return Request.CreateResponse<UserApiModel>(HttpStatusCode.BadRequest, userApiModel);
            }
        }

        [HttpGet]
        [Route("api/Users")]
        public HttpResponseMessage GetUsers([FromUri] User_Get_DTO User_Get_DTO)
        {
            try
            {
                userApiModel.Users = userRepository.GetUsers(User_Get_DTO, ref obj);

                userApiModel.ReturnStatus = obj.ReturnStatus;
                userApiModel.ReturnMessage = obj.ReturnMessage;

                return Request.CreateResponse<UserApiModel>(HttpStatusCode.OK, userApiModel);
            }
            catch (Exception e)
            {
                userApiModel.ReturnStatus = false;
                userApiModel.ReturnMessage.Add("Something went wrong");

                return Request.CreateResponse<UserApiModel>(HttpStatusCode.BadRequest, userApiModel);
            }
        }

        [HttpPost]
        [Route("api/InsertUser")]
        public HttpResponseMessage InsertUser(User_Post_DTO User_Post_DTO)
        {
            try
            {
                userRepository.InsertUser(User_Post_DTO, ref obj);

                userApiModel.ReturnStatus = obj.ReturnStatus;
                userApiModel.ReturnMessage = obj.ReturnMessage;

                return Request.CreateResponse<UserApiModel>(HttpStatusCode.OK, userApiModel);
            }
            catch (Exception e)
            {
                userApiModel.ReturnStatus = false;
                userApiModel.ReturnMessage.Add("Something went wrong");

                return Request.CreateResponse<UserApiModel>(HttpStatusCode.BadRequest, userApiModel);
            }
        }

        [HttpPut]
        [Route("api/UpdateUser")]
        public HttpResponseMessage UpdateUser(User_Post_DTO User_Post_DTO)
        {
            try
            {
                userRepository.UpdateUser(User_Post_DTO, ref obj);

                userApiModel.ReturnStatus = obj.ReturnStatus;
                userApiModel.ReturnMessage = obj.ReturnMessage;

                return Request.CreateResponse<UserApiModel>(HttpStatusCode.OK, userApiModel);
            }
            catch (Exception e)
            {
                userApiModel.ReturnStatus = false;
                userApiModel.ReturnMessage.Add("Something went wrong");

                return Request.CreateResponse<UserApiModel>(HttpStatusCode.BadRequest, userApiModel);
            }
        }

        [HttpDelete]
        [Route("api/DeleteUser")]
        public HttpResponseMessage DeleteUser(User_Post_DTO User_Post_DTO)
        {
            try
            {
                userRepository.DeleteUser(User_Post_DTO, ref obj);

                userApiModel.ReturnStatus = obj.ReturnStatus;
                userApiModel.ReturnMessage = obj.ReturnMessage;

                return Request.CreateResponse<UserApiModel>(HttpStatusCode.OK, userApiModel);
            }
            catch (Exception e)
            {
                userApiModel.ReturnStatus = false;
                userApiModel.ReturnMessage.Add("Something went wrong");

                return Request.CreateResponse<UserApiModel>(HttpStatusCode.BadRequest, userApiModel);
            }
        }

        [HttpGet]
        [Route("api/Login")]
        public HttpResponseMessage Login(string Password)
        {
            try
            {

                userApiModel.User = userRepository.Login(Password, ref obj);
                
                if (userApiModel.User != null)
                {
                    Dictionary<string, string> tokenDetails = GetTokenDetails("admin");

                    foreach (KeyValuePair<string, string> tokenDetail in tokenDetails)
                    {
                        if (tokenDetail.Key == "access_token")
                        {
                            userApiModel.TokenValue = tokenDetail.Value;
                        }
                    }

                    userApiModel.ReturnStatus = true;
                    userApiModel.ReturnMessage = obj.ReturnMessage;
                }
                else
                {
                    userApiModel.ReturnStatus = false;
                    userApiModel.ReturnMessage = obj.ReturnMessage;
                }

                return Request.CreateResponse<UserApiModel>(HttpStatusCode.OK, userApiModel);
            }
            catch (Exception e)
            {
                //userApiModel.ReturnStatus = false;
                //userApiModel.ReturnMessage.Add("Something went wrong");

                return Request.CreateResponse<UserApiModel>(HttpStatusCode.BadRequest, userApiModel);
            }
        }

        public Dictionary<string, string> GetTokenDetails(string userName)
        {
            Dictionary<string, string> tokenDetails = new Dictionary<string, string>();
            try
            {
                using (var client = new HttpClient())
                {
                    var loginDetails = new Dictionary<string, string>
                   {
                       {"grant_type", "password"},
                       {"username", userName}
                   };


                    //string tokenPathValue = "http://localhost:50120/token";
                    string tokenPathValue = "http://test.spokesdigital.us/token";

                    var response = client.PostAsync(tokenPathValue, new FormUrlEncodedContent(loginDetails)).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        if (response.Content.ReadAsStringAsync().Result.Contains("access_token"))
                        {
                            tokenDetails = JsonConvert.DeserializeObject<Dictionary<string, string>>(response.Content.ReadAsStringAsync().Result);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return tokenDetails;
        }

        [HttpGet]
        [Route("api/TestApi")]
        public HttpResponseMessage TestApi(string text)
        {
            try
            {
                userApiModel.TestApi = userRepository.TestApi(text, ref obj);

                userApiModel.ReturnStatus = true;
                userApiModel.ReturnMessage = obj.ReturnMessage;

                return Request.CreateResponse<UserApiModel>(HttpStatusCode.OK, userApiModel);
            }
            catch (Exception e)
            {
                userApiModel.ReturnStatus = false;
                //userApiModel.ReturnMessage.Add("Something went wrong");

                return Request.CreateResponse<UserApiModel>(HttpStatusCode.BadRequest, userApiModel);
            }
        }


    }
}
