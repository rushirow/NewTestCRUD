﻿using System;
using System.Collections.Generic;
using System.Linq;
using UserCRUD.Data;
using UserCRUD.Interface;
using UserCRUD.Models;

namespace UserCRUD.Repository
{
    public class UserRepository : IUserRepository
    {
        UserDbEntities dbConnection = new UserDbEntities();
        public List<UserTbl> GetUsers(User_Get_DTO user_Get_DTO, ref ReturnObject obj)
        {
            List<UserTbl> Users = new List<UserTbl>();
            Users = (from u in dbConnection.UserTbl
                     orderby u.UserTblId descending
                     select u).ToList();

            if(Users.Count>0)
                obj.ReturnMessage.Add("User list found");
            else
                obj.ReturnMessage.Add("No users found");

            obj.ReturnStatus = true;

            return Users;
        }

        public UserTbl GetUser(User_Get_DTO user_Get_DTO, ref ReturnObject obj)
        {
            UserTbl user = new UserTbl();

            user = (from u in dbConnection.UserTbl
                    where u.UserTblId == user_Get_DTO.UserId
                    select u).FirstOrDefault();

            obj.ReturnMessage.Add("User data found");
            obj.ReturnStatus = true;

            return user;
        }

        public void InsertUser(User_Post_DTO user_Post_DTO, ref ReturnObject obj)
        {
            try
            {
                UserTbl user = new UserTbl();

                user.ForeName = user_Post_DTO.ForeName;
                user.SurName = user_Post_DTO.SurName;
                user.Email = user_Post_DTO.Email;
                user.CreatedDate = System.DateTime.Now;

                dbConnection.UserTbl.Add(user);
                dbConnection.SaveChanges();

                obj.ReturnMessage.Add("User added successfully");
                obj.ReturnStatus = true;
            }
            catch (Exception ex)
            {
                obj.ReturnMessage.Add("Database Error");
                obj.ReturnStatus = false;
            }
        }

        public void UpdateUser(User_Post_DTO user_Post_DTO, ref ReturnObject obj)
        {
            try
            {
                UserTbl user = new UserTbl();

                user = (from u in dbConnection.UserTbl
                        where u.UserTblId == user_Post_DTO.UserId
                        select u).FirstOrDefault();

                user.ForeName = user_Post_DTO.ForeName;
                user.SurName = user_Post_DTO.SurName;
                user.Email = user_Post_DTO.Email;
                user.CreatedDate = System.DateTime.Now;

                dbConnection.SaveChanges();

                obj.ReturnMessage.Add("User updated successfully");
                obj.ReturnStatus = true;
            }
            catch (Exception ex)
            {
                obj.ReturnMessage.Add("Database Error");
                obj.ReturnStatus = false;
            }
        }

        public void DeleteUser(User_Post_DTO user_Post_DTO, ref ReturnObject obj)
        {
            try
            {
                UserTbl user = new UserTbl();

                user = (from u in dbConnection.UserTbl
                        where u.UserTblId == user_Post_DTO.UserId
                        select u).FirstOrDefault();

                dbConnection.UserTbl.Remove(user);
                dbConnection.SaveChanges();

                obj.ReturnMessage.Add("User deleted successfully");
                obj.ReturnStatus = true;
            }
            catch (Exception ex)
            {
                obj.ReturnMessage.Add("Database Error");
                obj.ReturnStatus = false;
            }
        }

        public UserTbl Login(string Password, ref ReturnObject obj)
        {
            UserTbl user = new UserTbl();

            user = (from u in dbConnection.UserTbl
                    where u.Password == Password
                    select u).FirstOrDefault();

            if (user != null)
            {
                obj.ReturnMessage.Add("Success");
                obj.ReturnStatus = true;
            }
            else
            {
                obj.ReturnMessage.Add("Incorrect password");
                obj.ReturnStatus = false;
            }
            

            return user;
        }

        public string TestApi(string text, ref ReturnObject obj)
        {
            UserTbl user = new UserTbl();

            try
            {
                user = dbConnection.UserTbl.Where(x => x.UserTblId == 1).FirstOrDefault();

                obj.ReturnMessage.Add("Tested successfully");
                obj.ReturnStatus = true;
            }
            catch(Exception e)
            {
                obj.ReturnMessage.Add(e.StackTrace);
                obj.ReturnStatus = false;
            }
            
            return "Tested successfully";
        }
    }
}