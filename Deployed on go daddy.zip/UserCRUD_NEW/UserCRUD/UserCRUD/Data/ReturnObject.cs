﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace UserCRUD.Data
{
    public class ReturnObject
    {
        public bool ReturnStatus { get; set; }
        public List<String> ReturnMessage { get; set; }
        public Hashtable ValidationErrors;
        public Boolean IsAuthenicated;

        public ReturnObject()
        {
            ReturnMessage = new List<String>();
            ReturnStatus = true;
            ValidationErrors = new Hashtable();
            IsAuthenicated = false;
        }
    }
}